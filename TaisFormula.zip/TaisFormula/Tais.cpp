#include <iostream>
#include <vector>
#include <iterator>
#include <iomanip>

using namespace std;

int main(){

    int n;

    vector<int> integers;
    vector<int>::iterator intPointer;
    vector<double> floats;
    vector<double>::iterator floatPointer;

    cin >> n;

    for(int i = 0; i < n; i++){
        int ti;
        float vi;

        cin >> ti;
        cin >> vi;

        integers.push_back(ti);
        floats.push_back(vi);
    }

    float answer = 0;

    for(int i = 1; i < integers.size(); i++){
        double fractionAnswer= (floats[i-1] + floats[i]) /2;
        double answer2 = (integers[i] - integers[i-1]);
        answer+= fractionAnswer * answer2; 

    }

    std::cout<<std::setprecision(6);
    cout << answer / 1000;


}