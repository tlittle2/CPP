#include <iostream>
#include <map>
using namespace std;


int main(){
    int n;
    cin >> n;

    for(int i = 0; i < n; i++){
        int day;
        string month;

        cin >> day >> month;

        if(month == "Mar"){
            if(day < 21){
                cout << "Pisces\n";
            }else{
                cout << "Aries\n";
            }

        }

        else if(month == "Apr"){
            if(day < 21){
                cout << "Aries\n";
            }else{
                cout << "Taurus\n";
            }

        }

        else if (month == "May"){
            if(day < 21){
                cout << "Taurus\n";
            }else{
                cout << "Gemini\n";
            }

        } 

        else if (month == "Jun"){
            if(day < 22){
                cout << "Gemini\n";
            }else{
                cout << "Cancer\n";
            }

        }

        else if (month == "Jul"){
            if(day < 23){
                cout << "Cancer\n";
            }else{
                cout << "Leo\n";
            }
            
        }

        else if (month == "Aug"){
            if(day < 23){
                cout << "Leo\n";
            }else{
                cout << "Virgo\n";
            }


        }

        else if (month == "Sep"){
            if(day < 22){
                cout << "Virgo\n";
            }else{
                cout << "Libra\n";
            }

        }

        else if (month == "Oct"){
            if(day < 23){
                cout << "Libra\n";
            }else{
                cout << "Scorpio\n";
            }

        }

        else if (month == "Nov"){
            if(day < 23){
                cout << "Scorpio\n";
            }else{
                cout << "Sagittarius\n";
            }

        }

        else if (month == "Dec"){
            if(day < 22){
                cout << "Sagittarius\n";
            }else{
                cout << "Capricorn\n";
            }

        }

        else if (month == "Jan"){
            if(day < 21){
                cout << "Capricorn\n";
            }else{
                cout << "Aquarius\n";
            }            

        }

        else if (month == "Feb"){
            if(day < 20){
                cout << "Aquarius\n";
            }else{
                cout << "Pisces\n";
            }
        }

    }



}