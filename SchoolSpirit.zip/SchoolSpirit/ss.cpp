#include <iostream>
#include <math.h>
#include <vector>
#include <bits/stdc++.h> 
#include <queue>
using namespace std;

int main(){

    int n;
    double ans=0;
    
    vector<int> students;

    cin >> n;

    for(int i = 0; i < n; i++){
        float const1= 0.2;
        float const2= 0.8;
        
        int val;
        cin >> val;
        students.push_back(val);

        ans+= const1 * (val * pow(const2,i));
        
    
    
    }

    sort(students.begin(), students.end());

    for(int v: students){

        cout << v << ", ";
    }

    cout << "\n";


    cout << "Answer: " << ans << "\n";



}