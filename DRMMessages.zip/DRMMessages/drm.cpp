#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

    std::map<char, int> ourMap;
    std::map<char, int>::iterator mpIt;

    std::vector<char> alphabet= {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 
    'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    char* aPointer;    


    int main(){
        ourMap['A'] = 0;
        ourMap['B']= 1;
        ourMap['C']= 2;
        ourMap['D']= 3;
        ourMap['E']= 4;
        ourMap['F']= 5;
        ourMap['G']= 6;
        ourMap['H']= 7;
        ourMap['I']= 8;
        ourMap['J']= 9;
        ourMap['K']= 10;
        ourMap['L']= 11;
        ourMap['M']= 12;
        ourMap['N']= 13;
        ourMap['O']= 14;
        ourMap['P']= 15;
        ourMap['Q']= 16;
        ourMap['R']= 17;
        ourMap['S']= 18;
        ourMap['T']= 19;
        ourMap['U']= 20;
        ourMap['V']= 21;
        ourMap['W']= 22;
        ourMap['X']= 23;
        ourMap['Y']= 24;
        ourMap['Z']= 25; 

        string s;
        int count1= 0;
        int count2= 0;

        string s1;
        string s2;
        cin >> s;

        for(int i = 0; i < s.size() /2; i++){
            s1 += s[i];
        }
        for(int i = s.size() /2; i < s.size(); i++){
            s2 += s[i];
        }


        for(char c: s1){
            count1 += ourMap.at(c);
        }
        for(char c: s2){
            count2 += ourMap.at(c);
        }

        cout << count1;

        cout << count2;
       
        cout << "\n";
        string newS1;
        string newS2;

         for(char c: s1){
             aPointer= &alphabet[0];
             while(*aPointer != c){
                 aPointer++;
             }
             aPointer += count1;
             cout << *aPointer;
            
        }


    /*
        for(char c: s1){
            newS1+= static_cast<char>(c + count1 % 26);
            
        }
        cout << newS1;
        
        cout << "\n";
        
        for(char c: s2){
            newS2+= static_cast<char>(c + count2 % 26);
            
        }
        cout << newS2;
    */


}