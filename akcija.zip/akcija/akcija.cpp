#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

    int main(){
        int sum= 0; //overall sum
        int sub=0; //temporary value for storing and adding the values at the end of our groups of 3
        int inputs;
        cin >> inputs;
        vector<int> myVector;

        //"TAKE 3, PAY FOR THE 2 MORE EXPENSIVE ONES"
        //Trying to get the least amount possible

        //append all values to vector and sort in ascending order
        for(int i = 0; i < inputs; i++){
            int value;
            cin >> value;
            myVector.push_back(value);
            sum+=value;

        }
        std::sort(myVector.begin(), myVector.end()); 
        

        //go in groups of threes to figure out the smallest value in a certain group (will loop back around if there is no third value)
        for(int i = myVector.size()- 3; i >= 0; i-=3){
            sub+= myVector[i];

        }
        //sum of all values - sub gets us the lowest we can get
        cout << sum- sub;
  
    
    }