#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

    int main(){
        int n;
        int count= 0;

        vector<char>correct;
        std::vector<char>::iterator correctIt;
        vector<char>answers;
        std::vector<char>::iterator answersIt;

        cin >> n;

        for(int i = 0; i <n; i++){
            char c;
            cin >> c;
            correct.push_back(c);          
        
        }

        for(int i = 1; i < correct.size(); i++){
            answersIt= answers.begin();
            answers.push_back(correct[i]);        
        }


        for(int i = 0; i < correct.size()-1; i++){
            if(correct[i] == answers[i]){
                count++;
            }
        }

        cout << count;
    
    }