#include <iostream>
#include <string>
#include <math.h>
using namespace std;

//R S T E E O T C P= TOPSECRET
        //The length of the input is 9 (sqrt is 3)
        //set our pointer at the the third element (the first T), and have a backwards loop go until the beginning of input 
                //to move the pointer
            //From the pointer, get the characters in increments of the sqrt root value until the end of input 

    int main(){
        int n;
        cin >> n;

        for(int i = 0; i < n; i++){
            string message;
            cin >> message;

            int start = sqrt(message.size());  //the size will always be a square

            char* ptr;  //set a char pointer for each character of input

            for(int j = start-1; j >= 0; j--){
                ptr= &message[j]; //set our ptr equal to the index of the square rooted element-1 (-1 to take into account 0-index)
                                  //We set the loop going backwards so that we can get character 1 back until we get to the beginning

                for(int k = j; k < message.size(); k+=start){
                    cout << message[k]; //get the characters in increments of the square rooted value;
                }

            }
            cout << "\n";

        }
    }