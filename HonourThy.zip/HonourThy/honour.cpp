#include <iostream>
#include <string>

using namespace std;
int main(){
    string kid, parent;

    cin >> kid >> parent;

    char lastChar= kid.length()-1;
    
    if(kid.at(lastChar) == 'e'){
        //cout << "first if";
        cout << kid << "x" << parent;

    }else if(kid.at(kid.length() -2)== 'e' && kid.at(lastChar) == 'x'){
        //cout << "second if";
        cout << kid << parent;

    }else if(kid.at(lastChar) == 'a' || kid.at(lastChar)== 'i' || kid.at(lastChar) == 'o' || kid.at(lastChar) == 'u'){
        kid= kid.erase(kid.length()-1);
        cout << kid << "ex" << parent;

    }else{
        //cout << "else";
        cout << kid << "ex" << parent;
    }


}