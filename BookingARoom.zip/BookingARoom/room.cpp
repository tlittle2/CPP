#include <iostream>
#include <vector>
#include <algorithm>
#include <stdlib.h> 

using namespace std;


int main(){
    int rooms;
    int lines;

    vector<int> bookings;

    vector<int> open;

    cin >> rooms >> lines;

    for(int i = 1; i <= lines; i++){
        int room;

        cin >> room;

        bookings.push_back(room);


    }

    bool full= true;
    for(int i = 1; i <= rooms; i++){
        bool valToFind= std::find(bookings.begin(), bookings.end(), i) != bookings.end();
        if(!valToFind){
            full = false;
            open.push_back(i);
        }
    }

    if(full){
        cout << "too late";
    }else{
        cout << open[0];
    }
}