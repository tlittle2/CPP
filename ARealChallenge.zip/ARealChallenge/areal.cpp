#include <iostream>
#include <math.h>

using namespace std;



int main(){
    long n;
    
    cin >> n;

    printf("%.16f", sqrt(n) * 4);
}