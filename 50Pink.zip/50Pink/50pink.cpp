#include <iostream>
#include <vector>
#include <string>

using namespace std;


int main(){
    int n;
    int count = 0;

    cin>>n;

    for(int i = 0; i < n; i++){
        std::string word;

        cin >> word;

        string newWord;
        for(char c: word){
            char lowerC= tolower(c);
            newWord+=lowerC;
        }
        
        if(newWord.find("pink") != std::string::npos){
            count++;
        }

        else if(newWord.find("rose") != std::string::npos){
            count++;
        }
        
    }

    if(count == 0){
        cout << "I must watch Star Wars with my daughter" << endl;
    }else{
        cout << count << endl;

    }

    

}