#include <iostream>

using namespace std;

int solve(int v){
    if(v == 3){
        return 0;
    }
    if(v == 4){
        return 1;
    }


    /*
    v == 3 -> 0

    v== 4 -> 1

    v== 5 -> 5

    v == 6 -> 15

    */

    
}


int main(){
    int n;

    cin >> n;

    cout << solve(n);

}