#include <iostream>
#include <map>
#include <algorithm>
#include <string>
using namespace std;

    std::map<char, string> ourMap;
    std::map<char, string>::iterator it;

    int main(){
        ourMap['a'] = "@";
        ourMap['b']= "8";
        ourMap['c']= "(";
        ourMap['d']= "|)";
        ourMap['e']= "3";
        ourMap['f']= "#";
        ourMap['g']= "6";
        ourMap['h']= "[-]";
        ourMap['i']= "|";
        ourMap['j']= "_|";
        ourMap['k']= "|<";
        ourMap['l']= "1";
        ourMap['m']= "[]\\/[]";
        ourMap['n']= "[]\\[]";
        ourMap['o']= "0";
        ourMap['p']= "|D";
        ourMap['q']= "(,)";
        ourMap['r']= "|Z";
        ourMap['s']= "$";
        ourMap['t']= "']['";
        ourMap['u']= "|_|";
        ourMap['v']= "\\/";
        ourMap['w']= "\\/\\/";
        ourMap['x']= "}{";
        ourMap['y']= "`/";
        ourMap['z']= "2"; 

        string line;

        while (getline(cin, line)) {
            for(char c: line){
                c= tolower(c);
                if(ourMap.find(c) != ourMap.end()){
                    it= ourMap.find(c);
                    cout << it -> second;

                }else{
                    cout << c;
                }
                
            }
            break;
        }
           
    }