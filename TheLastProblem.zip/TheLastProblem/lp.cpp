#include <iostream>


using namespace std;


int main(){
    string name;

    cin >> name;

    cout << "Thank you, "<< name <<", and farewell!";


}