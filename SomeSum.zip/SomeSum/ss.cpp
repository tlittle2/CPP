#include <iostream>

using namespace std;


int main(){
    int n;

    cin >> n;

    int modNum = n % 4;

    if(modNum == 0){
        cout << "Even";
    }
    
    else if(modNum == 2){
        cout << "Odd";
    }

    else{
        cout << "Either";
    }

    
}