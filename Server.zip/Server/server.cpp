#include <iostream>

using namespace std;


int main(){
    int n;
    int t;

    cin >> n >> t;

    int answer = 0;
    int count = 0;
    for(int i = 0; i < n; i++){
        int s;

        cin >> s;

        answer += s;

        if(answer > t){
            break;
        }else{
            count++;
        }

    }

    cout << count;

}
