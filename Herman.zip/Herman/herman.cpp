#define _USE_MATH_DEFINES
#include <math.h>
//These two are necessary for using M_PI
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;



int main(){
    double n;

    cin >> n;

    cout.precision(8);

    cout << M_PI * pow(n, 2)<< "\n";

    cout << pow(n, 2) * 2 << "\n";

}