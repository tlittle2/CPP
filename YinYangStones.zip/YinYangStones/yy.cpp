#include <iostream>
#include <vector>

using namespace std;


int main(){

    vector<char>ourList;

    string values;

    cin>>values ;

    for(char c: values){
        ourList.push_back(c);
    }

    
    int wCount =0;
    int bCount =0;

    for(char c: ourList){
        if(c == 'W'){
            wCount++;
        }else{
            bCount++;
        }
    }

    if(bCount == wCount){
        cout << 1;
    }else{
        cout << 0;
    }



}