#include <iostream>
#include <cmath>

using namespace std;
int main(){
    while(true){
        double a, b, c;

        cin >> a >> b >> c;

        if(a == 0 && b == 0 && c == 0){
            break;
        }
        
        double pi = 3.1415926535;
        double area = pi *a*a;

        double answer = c / b * (2*a *2*a);

        cout << area <<  " " << answer << "\n";

        

        


    }
}