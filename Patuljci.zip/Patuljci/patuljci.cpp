#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;


int main(){
    vector<int> v1;
    int tempSum = 0;
    //read input into some vector v(exactly 9 lines of input)
    for(int i = 0; i < 9; i++){
        int n;
        cin >>n;
        v1.push_back(n);
        tempSum += n;
    }


    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            if(i != j && tempSum - v1[i] - v1[j] == 100){
                for(auto n: v1){
                    if(n!=v1[i] && n!=v1[j]){
                        cout << n << "\n";
                    }
                }
                return 0;
            }
        }
    }
    

    
    
}

    
